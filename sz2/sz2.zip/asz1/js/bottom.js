    document.write('<style>');
	document.write('.btn-success { background: rgb(37, 157, 171);}');
	document.write('.btn {padding:0px; border-radius: 2px; border: 1px solid transparent; transition:0.4s cubic-bezier(0.175, 0.885, 0.32, 1); border-image: none; text-align: center; line-height: 1.5384; font-size: 13px; font-weight: 400; margin-bottom: 0px; vertical-align: middle; display: inline-block; white-space: nowrap; cursor: pointer; -ms-user-select: none; -webkit-transition: all .4s cubic-bezier(.175, .885, .32, 1); -o-transition: all .4s cubic-bezier(.175, .885, .32, 1); -webkit-user-select: none; -moz-user-select: none; user-select: none;}');
	document.write('.view{background:#fcfcfc; border-top: 1px #eee solid; width: 100%; position: fixed; left:0px; bottom: 0px; width: 100%; padding: 9px 0px; overflow: hidden}');
	document.write('.w320px{width: 640px; margin: 0 auto; overflow: hidden; display: block;}');
	document.write('</style>');
document.write('<div class="view">');
document.write('<section class="w320px">');
document.write('<img style="float: left; width: 40px; height: 40px; border-radius: 100%;" width="40" height="40" src="../images/wl.jpg" tppabs="images/foot1.png" border="0">');
document.write('<div style="float: left; font-size: 13px; line-height: 18px; margin-left: 10px; color: #444">');
document.write('<span style="font-size: 12px;">老师微信: <span style="font-size: 14px;">');
document.write('<strong>');
document.write('<span class="wx_str" onclick="clickSpan()" style="color:#F00; font-weight:bold" ><script>document.write(Arr);</script></span>');
document.write('</strong>');
document.write('</span> 点击复制<br>立即添加获取湿疹治疗方法>>></span>');
document.write('</div>');
document.write('<div style="float:left; margin-left:7px" class="btn btn-success">');
document.write('<a href="weixin://" onClick="PIWI_SUBMIT.Weixin_Open()" style="color:#fff;padding: 7px 12px;line-height: 34px;">湿疹治疗咨询中&gt;</a>');
document.write('</div>');
document.write('</section>');
document.write('</div>');


