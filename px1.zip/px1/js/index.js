//这是微信复制JS
var returnCitySN = {
    'cip': '',
    'cid': '',
    'cname': '',
}
var box1 = document.getElementsByClassName('box-1')
var box2 = document.getElementsByClassName('box-2')
var t1 = document.getElementsByClassName('t-1')
var t2 = document.getElementsByClassName('t-2')
var btnBox = document.getElementById('btn')
var wx = document.getElementById("wx_strs").innerText;
var ans = {
    'hb': '好的亲，红斑鳞屑的常见形成原因是由皮肤癣菌感染所致的一种常见感染性皮肤病，患者皮肤上可出现红斑、丘疹、长鳞屑，常有脱皮、掉屑、瘙痒等表现。主要包括头癣、体癣、股癣、手癣、足癣和花斑癣等。环境湿热污染严重，工作压力大，暴晒、免疫机能低下、感染、物品刺激等会出现皮肤瘙痒、丘疹、长鳞屑等现象，严重的甚至出现红斑和脱屑症状，这是在警示:你已是皮肤真菌感染，需要对皮肤进行修复了，为了更好的帮助你，老师先了解一下你的情况，请认真回答老师接下来提问你的问题哦。',
    'sp': '好的亲，皮肤挠会起水泡或丘疹为致病性丝状真菌感染引起，足癣和手癣更为常见。临床可分为角化型、水疱型、丘疹鳞型、间擦型和体癣型等数种，也可混合出现。本病有传染倾向，其发生与密切接触患者的手足部位或用品，如拖鞋、浴盆、擦脚布等有很大关系。皮损呈多形性，如红斑、丘疹、水疱、糜烂、渗出、痂皮、脱屑，常数种形态同时存在。为了更好的帮助你，老师先了解一下你的情况，请认真回答老师接下来提问你的问题哦。',
    'sy': '好的亲，瘙痒难忍，是由于环境湿热污染严重，皮肤过敏，皮炎，病毒真菌感染导致的，胆酸浓度过高、内分泌紊乱等各种内外因素，使皮肤出现瘙痒、刺痛、泛红、长鳞等现象，严重的甚至出现红斑和脱屑症状，当皮肤瘙痒并伴有其他症状时，决不能等闲视之，不要“头痛医头、脚痛医脚”，为了更好的帮助你，老师先了解一下你的情况，请认真回答老师接下来提问你的问题哦。',
    'zlx': '好的亲，根据您的选择，初步诊断您的皮肤为真菌感染慢性期，主要表现为粗糙肥厚、苔癣样变。伴有色素改变，皮屑像松树皮一样，挠会掉屑，反复发作，有时剧痒难忍。如果现在能够及时调理改善，是不难解决的，要是拖着不管它，不仅感染的程度还会继续加重，范围也会扩大，就需要花费更多的时间和精力！',
    'whbh': '好的亲，根据您的选择，初步诊断您的皮肤为真菌感染急性期，表现为红斑、粟粒大丘疹，糜烂及血丝、起鳞屑，同时瘙痒。如果现在能够及时调理改善，是不难解决的，要是拖着不管它，不仅感染的程度还会继续加重，范围也会扩大，就需要花费更多的时间和精力！',
}
t1[0].innerHTML = '<i></i>hihi'


function showBox(t) {
    var msg = t.innerHTML
    var id = t.getAttribute('data-name')
    var info = ''
    var title = document.getElementById("title");
    btnBox.innerHTML = ''
    $("#btn").fadeOut()
    switch (id) {
        case 'hb':
            info = ans.hb;
            break
        case 'sp':
            info = ans.sp;
            break;
        case 'sy':
            info = ans.sy;
            break;
    }
    t1[0].innerHTML = `<i></i>${msg}`
    box1[0].style.display = 'block'
    // t2[0].innerHTML = `<i></i><img src="./index1_files/msg-loading.gif" style="width:25px">`
    // box2[0].style.display = 'block'
    box2[9].style.display = 'block'
    setTimeout(function () {
        box2[9].style.display = 'none'
        box2[0].style.display = 'block'
        t2[0].innerHTML = `<i></i>${info}`
        btnBox.innerHTML = `
        <button onclick="showBox1(this)">18-25岁</button>
        <button onclick="showBox1(this)">26-35岁</button>
        <button onclick="showBox1(this)">35岁以上</button>
        `
        var nowScroll = window.scrollY
        window.scrollTo(0, nowScroll + 500)
        setTimeout(function () {
            box2[1].style.display = 'block'
            title.style.display = 'block';
            var nowScroll = window.scrollY
            window.scrollTo(0, nowScroll + 500)
            setTimeout(function () {
                $("#btn").fadeIn(800)
            }, 700)
        }, 500)
    }, 1000)
}

function showBox1(t) {
    var msg = t.innerHTML
    var info = '平时吃辛辣刺激性食物会引发发红、瘙痒或是刺痛感吗？'
    btnBox.innerHTML = ""
    $("#btn").fadeOut()
    t1[1].innerHTML = `<i></i>${msg}`
    box1[1].style.display = 'block'
    // t2[1].innerHTML = `<i></i><img src="./index1_files/msg-loading.gif" style="width:25px">`
    box2[9].style.display = 'block'
    setTimeout(function () {
        box2[9].style.display = 'none'
        box2[2].style.display = 'block'
        t2[1].innerHTML = `<i></i>${info}`
        btnBox.innerHTML = `
        <button onclick="showBox2(this)">从不</button>
        <button onclick="showBox2(this)">偶尔</button>
        <button onclick="showBox2(this)">经常</button>
        `
        setTimeout(function () {
            $("#btn").fadeIn(800)
        }, 700)
        var nowScroll = window.scrollY
        window.scrollTo(0, nowScroll + 500)
    }, 1000)
}

function showBox2(t) {
    var msg = t.innerHTML
    var info = '是否涂过含激素的产品？'
    btnBox.innerHTML = ""
    $("#btn").fadeOut()
    t1[2].innerHTML = `<i></i>${msg}`
    box1[2].style.display = 'block'
    // t2[2].innerHTML = `<i></i><img src="./index1_files/msg-loading.gif" style="width:25px">`
    box2[9].style.display = 'block'
    setTimeout(function () {
        box2[9].style.display = 'none'
        box2[3].style.display = 'block'
        t2[2].innerHTML = `<i></i>${info}`
        btnBox.innerHTML = `
        <button onclick="showBox3(this)">是</button>
        <button onclick="showBox3(this)">否</button>
        <button onclick="showBox3(this)">不肯定</button>
        `
        setTimeout(function () {
            $("#btn").fadeIn(800)
        }, 700)
        var nowScroll = window.scrollY
        window.scrollTo(0, nowScroll + 500)
    }, 1000)
}

function showBox3(t) {
    var msg = t.innerHTML
    var info = '你是否曾被皮肤科医生确诊为癣类、荨麻疹、神经性皮炎或湿疹？'
    btnBox.innerHTML = ""
    $("#btn").fadeOut()
    t1[3].innerHTML = `<i></i>${msg}`
    box1[3].style.display = 'block'
    // t2[3].innerHTML = `<i></i><img src="./index1_files/msg-loading.gif" style="width:25px">`
    box2[9].style.display = 'block'
    setTimeout(function () {
        box2[9].style.display = 'none'
        box2[4].style.display = 'block'
        t2[3].innerHTML = `<i></i>${info}`
        btnBox.innerHTML = `
        <button onclick="showBox6(this)">是</button>
        <button onclick="showBox6(this)">否</button>
        <button onclick="showBox6(this)">没诊断过</button>
        `
        setTimeout(function () {
            $("#btn").fadeIn(800)
        }, 700)
        var nowScroll = window.scrollY
        window.scrollTo(0, nowScroll + 500)
    }, 1000)
}

function showBox4(t) {
    var msg = t.innerHTML
    var info = '你的皮肤看上去发红或长鳞吗？'
    btnBox.innerHTML = ""
    $("#btn").fadeOut()
    t1[4].innerHTML = `<i></i>${msg}`
    box1[4].style.display = 'block'
    // t2[4].innerHTML = `<i></i><img src="./index1_files/msg-loading.gif" style="width:25px">`
    box2[9].style.display = 'block'
    setTimeout(function () {
        box2[9].style.display = 'none'
        box2[5].style.display = 'block'
        t2[4].innerHTML = `<i></i>${info}`
        btnBox.innerHTML = `
        <button data-name="whbh" onclick="showBox5(this)">不红</button>
        <button data-name="whbh" onclick="showBox5(this)">微红</button>
        <button data-name="zlx" onclick="showBox5(this)">长鳞屑</button>
        `
        setTimeout(function () {
            $("#btn").fadeIn(800)
        }, 700)
        var nowScroll = window.scrollY
        window.scrollTo(0, nowScroll + 500)
    }, 1000)
}

function showBox5(t) {
    var msg = t.innerHTML
    var name = t.getAttribute('data-name')
    var info = ''
    switch (name) {
        case 'zlx':
            info = ans.zlx;
            break
        case 'whbh':
            info = ans.whbh;
            break;
    }
    btnBox.innerHTML = ""
    $("#btn").fadeOut()
    t1[5].innerHTML = `<i></i>${msg}`
    box1[5].style.display = 'block'
    // t2[5].innerHTML = `<i></i><img src="./index1_files/msg-loading.gif" style="width:25px">`
    box2[9].style.display = 'block'
    setTimeout(function () {
        box2[9].style.display = 'none'
        box2[6].style.display = 'block'
        t2[5].innerHTML = `<i></i>${info}`
        btnBox.innerHTML = `
        <button onclick="showBox6(this)">联系老师</button>
        <button onclick="showBox6(this)">领取修复方案</button>
        `
        var nowScroll = window.scrollY
        window.scrollTo(0, nowScroll + 500)
        setTimeout(function () {
            box2[7].style.display = 'block'
            setTimeout(function () {
                $("#btn").fadeIn(800)
            }, 700)
            var nowScroll = window.scrollY
            window.scrollTo(0, nowScroll + 500)
        }, 500)
    }, 1000)
}

function showBox6(t) {
    var msg = t.innerHTML
    $("#btn").css('display', 'none')
    t1[6].innerHTML = `<i></i>${msg}`
    box1[6].style.display = 'block'
    box2[9].style.display = 'block'
    setTimeout(function () {
        box2[9].style.display = 'none'
        box2[8].style.display = 'block'
        setTimeout(function () {
            $("#btn1").fadeIn(800)
        }, 700)

        var nowScroll = window.scrollY
        window.scrollTo(0, nowScroll + 500)
    }, 1000)

}

let box = document.getElementsByClassName("box-load")
$("#boxx").css("display", 'none')
$("#footer").css("display", 'none')
$(".main").css("display", 'block')
setTimeout(function () {
    $("#loading").css('display', 'none')
    box[0].style.display = 'block'
    setTimeout(function () {
        box[1].style.display = 'block'
        setTimeout(function () {
            $("#btn").fadeIn(800)
        }, 700)

    }, 500)
}, 2000)


$('.bee-box-close').click(function () {
    $('.bee-box').css('display', 'none')
})

var top1 = document.getElementById('title')
window.document.addEventListener('scroll', function () {
    var top = window.scrollY
    if (top > 60)
        top1.classList.add('title-top')
    else
        top1.classList.remove('title-top')
})


//这是复制微信的JS 不能删
function getWx() {
    let oInput = document.createElement('input');
    let content = getText()
    let boxShowArr = []
    let box = document.getElementsByClassName('box')
    let boxlen = box.length
    let boxIndex;
    for (let i = 0; i < boxlen; i++) {
        if (box[i].style.display == 'block')
            boxShowArr.push(i)
    }
    boxIndex = (boxShowArr[(boxShowArr.length) - 1])
    oInput.value = document.getElementById("wx_strs").innerText;
    document.body.appendChild(oInput);
    oInput.select();
   var a =  document.execCommand("Copy");
    if (!a) {//兼容ios
        oInput.select(); // 选择对象
        oInput.setSelectionRange(0, oInput.value.length), document.execCommand('Copy');// 执行浏览器复制命令
    }
    oInput.style.display = 'none';
    document.body.removeChild(oInput);
    $(".box").eq(boxIndex).after(content);
    window.scrollTo(0, window.scrollY + 500);
    var href = window.location.href;

    if (href.indexOf('keyword=') == -1) {

        var keywords = Array();

        keywords[0] = '无';

    } else {

        var keywords = href.split('keyword=');

        var keywords = keywords[1].split('&');

    }

    if (href.indexOf('creative=') == -1) {

        var creative = Array();

        creative[0] = '无';

    } else {

        var creative = href.split('creative=');

        var creative = creative[1].split('&');

    }

    if (href.indexOf('plan=') == -1) {

        var plan = Array();

        plan[0] = '无';

    } else {

        var plan = href.split('plan=');

        var plan = creative[1].split('&');

    }

    $.ajax({

        url: 'https://wxdata.beehivedance.com/Message',

        type: 'post',

        data: {

            wechat: wchat,

            terrace: 'B-皮肤-百度信息流-K-2-咨询',

            keywords: keywords[0],

            creative: creative[0],

            plan: plan[0],

            ipaddres: '127.0.0.1',

            city: '广州xx',

            url: window.location.host,

        },

        success: function (data) {

        }

    });
}

function getText() {
    return `
  <div class="box3">
  <img src="./img/p1.jpg" class="img-1">
  <div class="chat-box">
      <i></i>
      亲！微信已成功复制，请您打开微信，在添加好友界面粘贴搜索，添加老师微信为好友，一对一免费咨询！
      <img src="./img/heihei.png">
  </div>
</div>`
}

//这是微信复制JS





